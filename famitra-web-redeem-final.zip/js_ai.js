/* =========================================== Asisten AI (khusus Owner) =====
   Tiga bagian: banner ringkasan di puncak dashboard, widget melayang dengan
   status mini/panel/penuh, dan sapaan proaktif yang muncul tanpa diminta.

   Semua data dimuat ulang setiap kali dashboard dibuka — tanpa cache — supaya
   ringkasannya selalu mencerminkan keadaan saat itu.

   Batasan UI (agar widget tidak memenuhi dashboard):
   - Hanya 3 saran teratas yang ditampilkan langsung di footer. Sisanya
     disembunyikan di balik tombol "Saran lainnya".
   - Sapaan proaktif ringkas (maks 1 sekaligus, dengan cooldown 30 detik),
     supaya tidak menumpuk bubble yang menghalangi input.
   ========================================================================= */

var AI_CABANG_VALID = ['KARLA', 'PUCUK', 'KENDAL', 'PULE'];
function cabangAIAktif() {
  var cabang = SESSION && SESSION.user && SESSION.user.cabang_id;
  return AI_CABANG_VALID.indexOf(cabang) !== -1 ? cabang : '';
}

var AI = {
  status: 'mini',        // mini | panel | full
  riwayat: [],           // { peran: 'me'|'ai', teks }
  saran: [],
  proaktifTampil: false,
  proaktifCooldown: 0,   // timestamp terakhir proaktif
  sedangTanya: false
};

function siapkanAsisten() {
  var dock = document.getElementById('aidock');
  dock.hidden = false;
  aiSetStatus('mini');

  document.getElementById('aidockFab').onclick = function () { aiSetStatus('panel'); };
  document.getElementById('aidockMin').onclick = function () { aiSetStatus('mini'); };
  document.getElementById('aidockSize').onclick = function () {
    aiSetStatus(AI.status === 'full' ? 'panel' : 'full');
  };
  document.getElementById('aidockKirim').onclick = aiKirim;
  document.getElementById('aidockInput').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') aiKirim();
  });

  if (!AI.riwayat.length) {
    aiTulis('ai', 'Halo Bu Isnah, ada yang bisa saya bantu?');
  }
}

function aiSetStatus(s) {
  AI.status = s;
  var dock = document.getElementById('aidock');
  dock.className = 'aidock ' + s;
  document.getElementById('aidockFab').hidden = (s !== 'mini');
  document.getElementById('aidockBox').hidden = (s === 'mini');
  if (s !== 'mini') {
    document.getElementById('aidockBadge').hidden = true;
    var b = document.getElementById('aidockBody');
    b.scrollTop = b.scrollHeight;
  }
}

/* --------------------------------------------------- Banner ringkasan ---- */

/**
 * Dipanggil dashboard setelah angka utamanya tampil. Sengaja tidak ditunggu:
 * kalau AI yang ditunggu, dashboard terasa lambat padahal datanya sudah siap.
 */
function muatBannerAI() {
  var el = document.getElementById('aiBanner');
  if (!el) return;
  var cfg = window.AI_CFG || {};
  if (!cfg.summaryUrl || /REPLACE_ME/.test(cfg.summaryUrl)) {
    el.innerHTML =
      '<div class="aibanner-top"><span class="aibanner-tag">Ringkasan hari ini</span></div>' +
      '<p>Asisten AI belum dikonfigurasi. Isi <code>window.AI_CFG</code> di <code>Index.html</code> dengan URL webhook n8n.</p>';
    AI.saran = [];
    gambarSaran();
    return;
  }

  var cabang = cabangAIAktif();
  if (!cabang) {
    el.innerHTML = '<div class="aibanner-top"><span class="aibanner-tag">Ringkasan hari ini</span></div>' +
      '<p>Cabang sesi tidak valid. Ringkasan AI tidak dimuat.</p>';
    return;
  }
  fetch(cfg.summaryUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      /* n8n workflow ai-summary memakai Header Auth Name="token" — bukan
         Authorization Bearer. Kirim sebagai field header terpisah. */
      'token': cfg.token || ''
    },
    body: JSON.stringify({
      cabang: cabang,
      role: (SESSION && SESSION.user && SESSION.user.role) || '',
      filter: bacaFilter && bacaFilter('db') ? bacaFilter('db') : { mode: 'hari_ini' }
    })
  }).then(function (r) {
    return r.text().then(function (text) {
      if (!text || !text.trim()) throw new Error('Webhook mengembalikan response kosong.');
      var j;
      try { j = JSON.parse(text); } catch (e) { throw new Error('Response webhook bukan JSON: ' + text.slice(0, 160)); }
      return { ok: r.ok, body: Array.isArray(j) ? (j[0] || {}) : j };
    });
  }).then(function (res) {
    if (!res.ok || !res.body || res.body.ok === false) {
      throw new Error((res.body && res.body.error) || 'Gagal memuat ringkasan.');
    }
    var d = res.body.data || {};
    var sorot = (d.sorotan || []).map(function (s) {
      return '<div><div class="sorot-label">' + esc(s.label) + '</div>' +
        '<div class="sorot-nilai">' + esc(s.nilai) + '</div>' +
        '<div class="sorot-catatan">' + esc(s.catatan) + '</div></div>';
    }).join('');

    el.innerHTML =
      '<div class="aibanner-top">' +
        '<span class="aibanner-tag">Ringkasan hari ini</span>' +
      '</div>' +
      '<p>' + esc(d.ringkasan || '') + '</p>' +
      '<div class="aibanner-sorot">' + sorot + '</div>';

    AI.saran = d.saran || [];
    gambarSaran();
    /* Proaktif sengaja ditahan: kalau summary sudah sarat info, gelembung
       tambahan hanya memenuhi widget. Owner klik FAB untuk membuka chat. */
    AI.proaktifTampil = false;
  }).catch(function (e) {
    el.innerHTML =
      '<div class="aibanner-top"><span class="aibanner-tag">Ringkasan hari ini</span></div>' +
      '<p>Asisten AI tidak dapat dihubungi: ' + esc(e.message) + '</p>' +
        '<p class="aibanner-petunjuk">Cek URL webhook <code>window.AI_CFG.summaryUrl</code> ' +
        'dan Header Auth <code>token</code> di workflow <code>ai-summary</code>.</p>';
  });
}

function bannerKerangka() {
  return '<div class="aibanner" id="aiBanner">' +
    '<div class="aibanner-top"><span class="aibanner-tag">Ringkasan hari ini</span></div>' +
    '<p class="memuat">Membaca penjualan, stok, dan pelanggan…</p>' +
  '</div>';
}

/* ------------------------------------------------- Sapaan proaktif ------- */

/**
 * Dipanggil eksplisit saat Owner membuka panel chat. Tidak muncul otomatis
 * di dashboard — kalau dipaksa, gelembung menumpuk dan menutupi input.
 * Cooldown 30 detik antar proaktif agar tidak spam.
 */
function tampilkanProaktif(list) {
  if (!list || !list.length) return;
  var now = Date.now();
  if (now - AI.proaktifCooldown < 30000) return;
  AI.proaktifCooldown = now;
  AI.proaktifTampil = true;

  /* Tampilkan satu per satu (maks 2) dengan jeda supaya Owner sempat
     membaca. */
  list.slice(0, 2).forEach(function (p, i) {
    setTimeout(function () {
      aiTulis('ai', p.teks, { aksi: p.aksi, nomor_wa: p.nomor_wa, proaktif: true });
      if (AI.status === 'mini') {
        var badge = document.getElementById('aidockBadge');
        badge.textContent = String(Number(badge.textContent || 0) + 1);
        badge.hidden = false;
      }
    }, 700 + i * 1200);
  });
}

/* ---------------------------------------------------------- Percakapan --- */

function aiTulis(peran, teks, opsi) {
  opsi = opsi || {};
  AI.riwayat.push({ peran: peran, teks: teks });

  var body = document.getElementById('aidockBody');
  if (!body) return;

  var kelas = 'bubble ' + (peran === 'me' ? 'me' : 'ai') + (opsi.proaktif ? ' proaktif' : '');
  var aksi = '';
  if (opsi.aksi) {
    aksi = '<button class="aksi-cepat" data-tanya="' + esc(opsi.aksi) + '"' +
      (opsi.nomor_wa ? ' data-wa="' + esc(opsi.nomor_wa) + '"' : '') + '>' +
      esc(opsi.aksi) + '</button>';
  }
  var tag = opsi.sumber === 'lokal' ? '<div class="sumber-tag">Dijawab dari data lokal</div>' : '';

  var div = document.createElement('div');
  div.className = kelas;
  div.innerHTML = esc(teks) + aksi + tag;
  body.appendChild(div);
  body.scrollTop = body.scrollHeight;
  return div;
}

/**
 * Tampilkan 3 saran teratas sebagai chip ringkas di footer. Sisanya
 * disembunyikan di balik tombol "Saran lainnya" — klik untuk expand.
 * Mencegah widget penuh dengan chip yang menghabiskan ruang footer.
 */
function gambarSaran() {
  var el = document.getElementById('aidockSaran');
  if (!el) return;
  var list = AI.saran || [];
  var top = list.slice(0, 3);
  var rest = list.slice(3);
  var html = top.map(function (q) {
    return '<button data-tanya="' + esc(q) + '">' + esc(q) + '</button>';
  }).join('');
  if (rest.length) {
    html += '<button class="saran-toggle" data-toggle="more">+' + rest.length +
      ' lagi</button><div class="saran-more" hidden>' +
      rest.map(function (q) {
        return '<button data-tanya="' + esc(q) + '">' + esc(q) + '</button>';
      }).join('') + '</div>';
  }
  el.innerHTML = html;
}

/* Satu penangan klik untuk seluruh tombol saran dan aksi cepat. */
document.addEventListener('click', function (e) {
  var tog = e.target.closest('[data-toggle="more"]');
  if (tog) {
    var saranWrap = tog.parentElement;
    if (saranWrap) saranWrap.classList.toggle('is-open');
    return;
  }
  var b = e.target.closest('[data-tanya]');
  if (!b) return;
  if (b.dataset.wa) {
    var pesan = 'Halo, salam dari Apotek Fa-Mitra. Kami ingin memastikan kebutuhan obat Anda tetap tercukupi.';
    window.open('https://wa.me/' + b.dataset.wa + '?text=' + encodeURIComponent(pesan), '_blank');
    return;
  }
  if (AI.status === 'mini') aiSetStatus('panel');
  aiTanya(b.dataset.tanya);
});

function aiKirim() {
  var input = document.getElementById('aidockInput');
  var q = input.value.trim();
  if (!q) return;
  input.value = '';
  aiTanya(q);
}

function aiTanya(q) {
  if (AI.sedangTanya) { toast('Tunggu jawaban sebelumnya selesai.', true); return; }
  var cfg = window.AI_CFG || {};
  if (!cfg.chatUrl || /REPLACE_ME/.test(cfg.chatUrl)) {
    aiTulis('ai', 'Asisten AI belum dikonfigurasi. Isi window.AI_CFG di Index.html dengan URL webhook n8n.');
    return;
  }
  var cabang = cabangAIAktif();
  if (!cabang) {
    aiTulis('ai', 'Cabang sesi tidak valid. Asisten AI tidak dapat digunakan.');
    return;
  }
  AI.sedangTanya = true;

  aiTulis('me', q);
  var tunggu = aiTulis('ai', 'Sedang membaca data…');

  /* ai-chat workflow n8n di-set tanpa auth (CORS *). Tetap kirim token di
     body untuk kompatibilitas, JANGAN kirim Authorization header (kalau
     dikirim dengan nilai yang tidak cocok, preflight n8n bisa gagal). */
  fetch(cfg.chatUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'token': cfg.token || ''
    },
    body: JSON.stringify({
      cabang: cabang,
      role: (SESSION && SESSION.user && SESSION.user.role) || '',
      q: q,
      riwayat: AI.riwayat.slice(-8)
    })
  }).then(function (r) {
    return r.text().then(function (text) {
      if (!text || !text.trim()) throw new Error('Webhook mengembalikan response kosong.');
      var j;
      try { j = JSON.parse(text); } catch (e) { throw new Error('Response webhook bukan JSON: ' + text.slice(0, 160)); }
      return { ok: r.ok, body: Array.isArray(j) ? (j[0] || {}) : j };
    });
  }).then(function (res) {
    if (!res.ok || !res.body || res.body.ok === false) {
      throw new Error((res.body && res.body.error) || 'Gagal menghubungi asisten.');
    }
    var r = res.body.data || {};
    var follow = r.pertanyaan_lanjutan ? '<div class="ai-followup">' + esc(r.pertanyaan_lanjutan) + '</div>' : '';
    tunggu.innerHTML = esc(r.jawaban || '') + follow +
      (r.sumber === 'lokal' ? '<div class="sumber-tag">Dijawab dari data lokal</div>' : '');
    AI.saran = Array.isArray(r.saran) ? r.saran.slice(0, 2) : [];
    gambarSaran();
    AI.riwayat[AI.riwayat.length - 1] = { peran: 'ai', teks: (r.jawaban || '') + (r.pertanyaan_lanjutan ? '\n' + r.pertanyaan_lanjutan : '') };
    document.getElementById('aidockBody').scrollTop = 99999;
  }).catch(function (e) {
    tunggu.textContent = 'Gagal: ' + e.message;
  }).then(function () { AI.sedangTanya = false; });
}
